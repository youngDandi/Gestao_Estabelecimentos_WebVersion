<?php
require_once '../DAO/diretorDAO.php';
            $diretorDAO = new diretorDAO();
           if(isset($_GET['id'])){
                $id=$_GET['id'];
                 if( $diretorDAO->apagar($id)){
                    

                echo "<script>alert('Deletado com sucesso!');document.location='/Estabelecimento/views/tabelaDiretor.php'</script>";


                 }else{
                   echo "<script>alert('Erro ao deletar!');history.back()</script>";  
                 }
                 

            }
       