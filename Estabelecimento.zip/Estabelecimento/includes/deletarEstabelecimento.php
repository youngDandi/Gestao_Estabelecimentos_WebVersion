<?php
require_once '../DAO/estabelecimentoDAO.php';
            $estabelecimentoDAO = new estabelecimentoDAO();
           if(isset($_GET['id'])){
                $id=$_GET['id'];
                 if( $estabelecimentoDAO->apagar($id)){
                    

                echo "<script>alert('Deletado com sucesso!');document.location='/Estabelecimento/views/tabelaEstabelecimento.php'</script>";


                 }else{
                   echo "<script>alert('Erro ao deletar!');history.back()</script>";  
                 }
                 

            }
       