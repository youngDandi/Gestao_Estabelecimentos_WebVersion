<?php
require_once '../DAO/traillerDAO.php';
            $traillerDAO = new traillerDAO();
           if(isset($_GET['id'])){
                $id=$_GET['id'];
                 if( $traillerDAO->apagar($id)){
                  echo "<script>alert('Deletado com sucesso!');document.location='/Estabelecimento/views/tabelaTrailler.php'</script>";
                 }else{
                   echo "<script>alert('Erro ao deletar!');history.back()</script>";  
                 }
                 

            }
       