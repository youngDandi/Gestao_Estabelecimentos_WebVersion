<?php
require_once '../DAO/lojaDAO.php';
            $lojaDAO = new lojaDAO();
           if(isset($_GET['id'])){
                $id=$_GET['id'];
                 if( $lojaDAO->apagar($id)){
                    

                echo "<script>alert('Deletado com sucesso!');document.location='/Estabelecimento/views/tabelaLoja.php'</script>";


                 }else{
                   echo "<script>alert('Erro ao deletar!');history.back()</script>";  
                 }
                 

            }
       