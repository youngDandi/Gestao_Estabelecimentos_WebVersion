<?php
ini_set('display_errors' ,1);
require_once '../DAO/Conecta.php';
class estabelecimentoDAO {

    private $db;
    public function __construct(){
        $this->db=new Conecta();
    }
      
    public function salvar(Estabelecimento $estabelecimento) {
        try {
            $con = new Conecta();
             $this->db->query("INSERT INTO estabelecimento(endereco,numero_Trabalhadores,quantidade_Produtos,diretor) Values(:endereco,:numero_Trabalhadores,:quantidade_Produtos,:diretor)");

           $this->db->bind(":endereco",$estabelecimento->getEndereco());
           $this->db->bind(":numero_Trabalhadores",$estabelecimento->getTrabalhadores());
           $this->db->bind(":quantidade_Produtos",$estabelecimento->getProdutos());
           $this->db->bind(":diretor",$estabelecimento->getDiretor());
          
             if($this->db->executa()):
           return true;
           else:
           return false;
           endif;
        } catch (PDOException $exc){
            echo "Erros de:". $exc->getMessage();
        }

    }

  

   public function listar(){
       $this->db->query("SELECT *FROM estabelecimento inner Join diretor ");
       return $this->db->resultados();
   }
   
   
   public function listarPorId($id){
       $this->db->query("SELECT *FROM estabelecimento where id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
   // dados do estabelecimento dado o codido do estabelecimento
   public function estabelecimentoNome($id){
      
       $this->db->query(" SELECT * FROM estabelecimento INNER JOIN estabelecimento ON estabelecimento.id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
 public function apagar($id){
         $this->db->query(" DELETE  FROM  estabelecimento  where id=:id");
         $this->db->bind('id',$id);
         return $this->db->executa();
   }
   public function Media(){

     $this->db->query("SELECT AVG(numero_Trabalhadores) FROM estabelecimento") ; 
     return  $this->db->resultado();    
   }
   public function endereco(){
       $this->db->query("SELECT endereco , max(quantidade_Produtos) FROM estabelecimento");
        return  $this->db->resultado();    
   }
   
}
