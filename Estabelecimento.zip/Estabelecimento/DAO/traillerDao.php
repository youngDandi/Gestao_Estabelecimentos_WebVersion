<?php
ini_set('display_errors' ,1);
require_once '../DAO/Conecta.php';
class traillerDAO {

    private $db;
    public function __construct(){
        $this->db=new Conecta();
    }
      
    public function salvar(Trailler $trailler) {
        try {
            $con = new Conecta();
           $this->db->query("INSERT INTO trailler(geladeira,contrato,loja,datee,endereco,distribuicao,rua,numero) Values(:geladaria,:contrato,:loja,:datee,:endereco,:distribuicao,:rua,:numero)");
           $this->db->bind(":geladaria",$trailler->getGeladaria());
           $this->db->bind(":contrato",$trailler->getContrato());
           $this->db->bind(":loja",$trailler->getLoja());
           $this->db->bind(":datee",$trailler->getData());
           $this->db->bind(":endereco",$trailler->getEndereco());
           $this->db->bind(":distribuicao",$trailler->getDistribuicao());
           $this->db->bind(":rua",$trailler->getRua());
           $this->db->bind(":numero",$trailler->getNumero());
          
             if($this->db->executa()):
           return true;
           else:
           return false;
           endif;
        } catch (PDOException $exc){
            echo "Erros de:". $exc->getMessage();
        }

    }

  

   public function listar(){
       $this->db->query("SELECT *FROM trailler inner Join loja ");
       return $this->db->resultados();
   }
   
   
   public function listarPorId($id){
       $this->db->query("SELECT *FROM trailler where id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
  public function apagar($id){
         $this->db->query(" DELETE  FROM  trailler  where id=:id");
         $this->db->bind('id',$id);
         return $this->db->executa();
   }

}
