<?php
ini_set('display_errors' ,1);
require_once '../DAO/Conecta.php';
class lojaDAO {

    private $db;
    public function __construct(){
        $this->db=new Conecta();
    }
      
    public function salvar(Loja $loja) {
        try {
            $con = new Conecta();
             $this->db->query("INSERT INTO loja(nome,numero_Caixas,numero_Departamentos,cafetaria) Values(:nome,:numero_Caixas,:numero_Departamentos,:cafetaria)");

           $this->db->bind(":nome",$loja->getNome());
           $this->db->bind(":numero_Caixas",$loja->getCaixas());
           $this->db->bind("numero_Departamentos",$loja->getDepartamentos());
           $this->db->bind(":cafetaria",$loja->getCafetaria());
          
             if($this->db->executa()):
           return true;
           else:
           return false;
           endif;
        } catch (PDOException $exc){
            echo "Erros de:". $exc->getMessage();
        }

    }

  

   public function listar(){
       $this->db->query("SELECT *FROM loja");
       return $this->db->resultados();
   }
   
   
   public function listarPorId($id){
       $this->db->query("SELECT *FROM loja where id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
   /*
   public function lojaNome($id){
      
       $this->db->query(" SELECT * FROM loja INNER JOIN loja ON loja.id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
   */
  public function apagar($id){
         $this->db->query(" DELETE  FROM  loja  where id=:id");
         $this->db->bind('id',$id);
         return $this->db->executa();
   }

}
