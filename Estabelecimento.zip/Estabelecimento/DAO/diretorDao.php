<?php
ini_set('display_errors' ,1);
require_once '../DAO/Conecta.php';
class diretorDAO {

    private $db;
    public function __construct(){
        $this->db=new Conecta();
    }
      
    public function salvar(Diretor $diretor) {
        try {
            $con = new Conecta();
             $this->db->query("INSERT INTO diretor(nome,sexo,experiencia) Values(:nome,:sexo,:experiencia)");

           $this->db->bind(":nome",$diretor->getNome());
           $this->db->bind(":sexo",$diretor->getSexo());
           $this->db->bind(":experiencia",$diretor->getExperiencia());
          
             if($this->db->executa()):
           return true;
           else:
           return false;
           endif;
        } catch (PDOException $exc){
            echo "Erros de:". $exc->getMessage();
        }

    }

  

   public function listar(){
       $this->db->query("SELECT *FROM diretor");
       return $this->db->resultados();
   }
   
   
   public function listarPorId($id){
       $this->db->query("SELECT *FROM diretor where id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
   // dados do diretor dado o codido do estabelecimento
   public function DiretorNome($id){
      
       $this->db->query(" SELECT * FROM estabelecimento INNER JOIN diretor ON estabelecimento.id=:id");
       $this->db->bind('id',$id);
       return $this->db->resultado();
   }
   public function apagar($id){
         $this->db->query(" DELETE  FROM  diretor  where id=:id");
         $this->db->bind('id',$id);
         return $this->db->executa();
   }

}
