<?php

class HomeControl
{
    public function index()
    {
        require_once path."/Estabelecimento/views/homeView.php";
    }
}
