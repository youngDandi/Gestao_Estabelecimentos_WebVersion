<?php

class lojaControler {
    
    public function valida(loja $loja){
        $erros = "";
        if ($loja->getNome() == ""){
            $erros .= "Nome em branco. <br>";
        }

        if ($loja->getCaixas() == ""){
            $erros .= "caixas em branco. <br>";
        }

        
       if ($loja->getDepartamentos() == ""){
            $erros .= "departamentos em branco. <br>";
        }

        return $erros;
    }
  
      public function cadastarLoja()
    {
        //require_once path."/Estabelecimento/views/Formularioloja.php";
    }
    public function homeLoja()
    {
        require_once path."/Estabelecimento/views/loja.php";
    }
    

  }
