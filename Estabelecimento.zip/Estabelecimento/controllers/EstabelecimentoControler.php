<?php

class EstabelecimentoControler {

    public function valida(Estabelecimento $estabelecimento){
        $erros = "";
        /*
        if ($estabelecimento->getEndereco() == ""){
            $erros .= "endereco em branco. <br>";
        }

        if ($estabelecimento->getProdutos() == ""){
            $erros .= "produtos em branco. <br>";
        }

        
        if ($estabelecimento->getTrabalhadores() == ""){
            $erros .= " Experiencia  em branco. <br>";
        }
         */

        return $erros;
    
    }
    public function cadastarEStabelecimento()
    {
        require_once path."/Estabelecimento/views/Formularioestabelecimento.php";
    }
    public function homeEstabelecimento()
    {
        require_once path."/Estabelecimento/views/estabelecimento.php";
    }
    
}
