<?php
class DiretorControler {

    public function __construct(){
        $this->Eliminar();
    }

    public function valida(Diretor $diretor){
        $erros = "";
        if ($diretor->getNome() == ""){
            $erros .= "Nome em branco. <br>";
        }

        if ($diretor->getSexo() == ""){
            $erros .= "Sexo em branco. <br>";
        }

        
        if ($diretor->getExperiencia() == ""){
            $erros .= " Experiencia  em branco. <br>";
        }


        return $erros;
    }
 public function registra()
    {
       // require_once path."/Estabelecimento/views/FormularioDiretor.php";
     echo "ola";
    }
    public function homeDiretor()
    {
        require_once path."/Estabelecimento/views/diretor.php";
     }
 
public function Eliminar(){
   
require_once '../DAO/diretorDAO.php';
            $diretorDAO = new diretorDAO();
           if(isset($_GET['id'])){
                $id=$_GET['id'];
                 if( $diretorDAO->apagar($id)){
                    

                echo "<script>alert('Deletado com sucesso!');document.location='/Estabelecimento/views/tabelaDiretor.php'</script>";


                 }else{
                   echo "<script>alert('Erro ao deletar!');history.back()</script>";  
                 }
                 

            }
}
       
}

 