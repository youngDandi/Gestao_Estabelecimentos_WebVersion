<?php

class traillerControler {
    
    public function valida(Trailler $trailler){
        $erros = "";
        if ($trailler->getEndereco() == ""){
            $erros .= "Nome em branco. <br>";
        }

        if ($trailler->getData() == ""){
            $erros .= "caixas em branco. <br>";
        }

        
       if ($trailler->getNumero() == ""){
            $erros .= "departamentos em branco. <br>";
        }

        return $erros;
    }
  
      public function cadastartrailler()
    {
        require_once path."/Estabelecimento/views/Formulariotrailler.php";
    }
    public function hometrailler()
    {
        require_once path."/Estabelecimento/views/trailler.php";
    }
    

  }
