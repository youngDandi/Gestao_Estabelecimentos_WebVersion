-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 06-Maio-2021 às 22:22
-- Versão do servidor: 10.4.14-MariaDB
-- versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `estabelecimento`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `diretor`
--

CREATE TABLE `diretor` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `sexo` varchar(30) NOT NULL,
  `experiencia` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `diretor`
--

INSERT INTO `diretor` (`id`, `nome`, `sexo`, `experiencia`) VALUES
(1, 'pedro cabinda', 'masculino', '20 anos'),
(2, 'chipa', 'feminino', '12 anos'),
(3, 'pedro chipa', 'masculino', '12'),
(4, 'pedro chipa', 'masculino', '12'),
(5, 'ana', 'feminino', '30 anos'),
(6, 'ana', 'feminino', '30 anos'),
(7, 'ana luis', 'feminino', '1'),
(8, 'pedro', 'feminino', 'qoooao'),
(9, 'xxxxxxxxxxx', 'feminino', '12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `estabelecimento`
--

CREATE TABLE `estabelecimento` (
  `id` int(11) NOT NULL,
  `endereco` varchar(30) NOT NULL,
  `diretor` int(11) NOT NULL,
  `numero_Trabalhadores` int(11) NOT NULL,
  `quantidade_Produtos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `estabelecimento`
--

INSERT INTO `estabelecimento` (`id`, `endereco`, `diretor`, `numero_Trabalhadores`, `quantidade_Produtos`) VALUES
(25, 'rua 11', 1, 1, 1),
(26, 'loja', 2, 2, 2),
(27, 'rua 12', 1, 4, 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `loja`
--

CREATE TABLE `loja` (
  `id` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `numero_Caixas` int(11) NOT NULL,
  `numero_Departamentos` int(11) NOT NULL,
  `cafetaria` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `loja`
--

INSERT INTO `loja` (`id`, `nome`, `numero_Caixas`, `numero_Departamentos`, `cafetaria`) VALUES
(1, 'big faita', 2, 2, 's'),
(10, 'Ana Bela', 2, 2, 's'),
(11, 'trigo', 20, 200, ''),
(12, 'dona malia', 1, 1, ''),
(13, 'joao begas', 2, 2, ''),
(14, 'ana luis lda', 4, 4, 'sim');

-- --------------------------------------------------------

--
-- Estrutura da tabela `trailler`
--

CREATE TABLE `trailler` (
  `id` int(11) NOT NULL,
  `geladeira` varchar(30) NOT NULL,
  `contrato` varchar(30) NOT NULL,
  `loja` int(11) NOT NULL,
  `datee` date NOT NULL DEFAULT current_timestamp(),
  `endereco` varchar(50) NOT NULL,
  `distribuicao` int(11) NOT NULL,
  `rua` varchar(50) NOT NULL,
  `numero` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `trailler`
--

INSERT INTO `trailler` (`id`, `geladeira`, `contrato`, `loja`, `datee`, `endereco`, `distribuicao`, `rua`, `numero`) VALUES
(1, 's', 's', 1, '2021-05-03', 'soa paulo', 1, 'fggg', 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `diretor`
--
ALTER TABLE `diretor`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `estabelecimento`
--
ALTER TABLE `estabelecimento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diretor` (`diretor`);

--
-- Índices para tabela `loja`
--
ALTER TABLE `loja`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `trailler`
--
ALTER TABLE `trailler`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loja` (`loja`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `diretor`
--
ALTER TABLE `diretor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `estabelecimento`
--
ALTER TABLE `estabelecimento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `loja`
--
ALTER TABLE `loja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `trailler`
--
ALTER TABLE `trailler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `trailler`
--
ALTER TABLE `trailler`
  ADD CONSTRAINT `trailler_ibfk_1` FOREIGN KEY (`loja`) REFERENCES `loja` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
