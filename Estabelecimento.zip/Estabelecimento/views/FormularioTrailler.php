
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <?php
      
    if (isset($_POST['endereco'])){
         
        require_once '../models/Trailler.php';
        $trailler= new Trailler();
        $trailler->setEndereco(trim($_POST["endereco"]));
        $trailler->setDistribuicao(trim($_POST["distribuicao"]));
        $trailler->setRua(trim($_POST["rua"]));
        $trailler->setNumero(trim($_POST["numero"]));
        $trailler->setLoja(trim($_POST["loja"]));
        $trailler->setContrato(trim($_POST["contrato"]));
        $trailler->setGeladaria(trim($_POST["geladaria"]));
        $trailler->setData(trim($_POST["data"]));
     
        require_once '../controllers/traillerControler.php';
        $ctrltrailler= new traillerControler();
        if ($ctrltrailler->valida($trailler) == ""){
            require_once '../DAO/traillerDao.php';
            $traillerDAO = new traillerDao();
            if ($traillerDAO->salvar($trailler)){
               echo "<script>alert('cadastrado com sucesso!');document.location='/Estabelecimento/views/tabelaTrailler.php'</script>";
            } else {
                echo "<script>alert('Erro ao cadastrar!');history.back()</script>";
            }
        } else {
             $e = $ctrltrailler->valida($trailler);
        }

        //Mostrar erros
        if (isset($m)){
           echo "<div class='alert alert-success'> <strong>".$m."</strong></div>";
        }
        if (isset($e)){
           echo "<div class='alert alert-danger'> <strong>".$e."</strong></div>";
        }
    }
    ?>
  
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(to right, rgb(255, 255, 255),  rgb(255, 255, 255));
        }
        .box{
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background-color: rgb(32,201,166);
            padding: 15px;
            border-radius: 15px;
            width: 50%;
        }
        fieldset{
            border: 3px solid rgb(255, 255, 255);
        }
        legend{
            border: 1px solid rgb(255, 255, 255);
            padding: 10px;
            text-align: center;
            background-color: rgb(68, 66, 66);
            border-radius: 8px;
        }
        .inputBox{
            position: relative;
        }
        .inputUser{
            background: none;
            border: none;
            border-bottom: 1px solid white;
            outline: none;
            color: white;
            font-size: 15px;
            width: 100%;
            letter-spacing: 2px;
        }
        .labelInput{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: .5s;
        }
        .inputUser:focus ~ .labelInput,
        .inputUser:valid ~ .labelInput{
            top: -20px;
            font-size: 12px;
            color: rgb(5, 5, 5);
        }
        #data_nascimento{
            border: none;
            padding: 8px;
            border-radius: 10px;
            outline: none;
            font-size: 15px;
        }
        #submit{
            background-image: linear-gradient(to right,rgb(255, 255, 255),  rgb(32,201,166));
            width: 100%;
            border: none;
            padding: 15px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            border-radius: 10px;
        }
        #submit:hover{
            background-image: linear-gradient(to right,rgb(0, 80, 172), rgb(255, 255, 255));
        }
    </style>
</head>
<body>
    <div class="box">
        <form action="" method="Post">
            <fieldset>
                <legend><b>Cadastro de trailler</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="endereco" id="endereco" class="inputUser" required>
                    <label for="endereco" class="labelInput">Endereco</label>
                </div>
                <br>
                <div class="inputBox">
                    <input type="text" name="distribuicao" id="distribuicao" class="inputUser" required>
                    <label for="distribuicao" class="labelInput">Distribuicao</label>
                </div>
                <br>
                <div class="inputBox">
                    <input type="text" name="rua" id="rua "class="inputUser" required>
                    <label for="rua" class="labelInput">Rua</label>
                </div>
                <br>
                 <div class="inputBox">
                    <input type="number" name="numero" id="numero" class="inputUser" required>
                    <label for="numero" class="labelInput">Numero </label>
                </div>
                 <p>Contrato(Nestle):</p>
                <input type="radio" id="sim" name="contrato" value="sim" required>
                <label for="sim">Sim</label>
                <br>
                <input type="radio" id="nao" name="contrato" value="nao" required>
                <label for="masculino">Nao</label>
                 <br> <br>
                  <p>Geladaria:</p>
                <input type="radio" id="sim" name="geladaria" value="sim" required>
                <label for="sim">Sim</label>
                <br>
                <input type="radio" id="nao" name="geladaria" value="nao" required>
                <label for="nao">Nao</label>
                 <br> <br>
                <br>
                <br>
                   <label>Loja:
                      
                    <select name="loja">
                        <option>Selecione  a loja</option>
                     
                        <?php 
                            require_once '../DAO/LojaDao.php';
                             $lojaDAO = new lojaDao();
                            $lista = $lojaDAO->listar();
                             foreach ($lista as $li):
                                $selecinado = "";
                                if(isset($li->id))
                                    $selecinado = ($li->id == $li->id) ? "selected" : "";
                            ?>
                        <option value="<?= $li->id ?>" <?= $selecinado ?> >
                            <?= $li->nome  ?> 
                        </option>

                        <?php endforeach ?>

                    </select>
                <br><br>
                 <div class="inputBox">
                    <input type="date" name="data" id="data "class="inputUser" required>
                    <label for="data" class="labelInput"></label>
                </div>
                <br>
                <input type="submit" name="submit" id="submit">
            </fieldset>
        </form>
    </div>
</body>
</html>