<?php 
require_once '../Ajax/scripts.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <?php
      
    if (isset($_POST['endereco'])){
         
        require_once '../models/Estabelecimento.php';
        $estabelecimento = new Estabelecimento();
        $estabelecimento->setEndereco(trim($_POST["endereco"]));
        $estabelecimento->setProdutos(trim($_POST["produtos"]));
        $estabelecimento->setTrabalhadores(trim($_POST["trabalhadores"]));
        $estabelecimento->setDiretor(trim($_POST["id_diretor"]));
     
        require_once '../controllers/EstabelecimentoControler.php';
        $ctrlestabelecimento = new EstabelecimentoControler();
        if ($ctrlestabelecimento->valida($estabelecimento) == ""){
            require_once '../DAO/EstabelecimentoDao.php';
            $estabelecimentoDao = new EstabelecimentoDao();
            if ($estabelecimentoDao->salvar($estabelecimento)){
                        echo "<script>alert('cadastrado com sucesso!');document.location='/Estabelecimento/views/tabelaEstabelecimento.php'</script>";
            } else {
                  echo "<script>alert('Erro ao cadastrar!');history.back()</script>";   
            }
        } else {
             $e = $ctrlestabelecimento->valida($estabelecimento);
        }

        //Mostrar erros
        if (isset($m)){
           echo "<div class='alert alert-success'> <strong>".$m."</strong></div>";
        }
        if (isset($e)){
           echo "<div class='alert alert-danger'> <strong>".$e."</strong></div>";
        }
    }
    ?>
  
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-image: linear-gradient(to right, rgb(255, 255, 255),  rgb(255, 255, 255));
        }
        .box{
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            background-color: rgb(32,201,166);
            padding: 15px;
            border-radius: 15px;
            width: 40%;
        }
        fieldset{
            border: 3px solid rgb(255, 255, 255);
        }
        legend{
            border: 1px solid rgb(255, 255, 255);
            padding: 10px;
            text-align: center;
            background-color: rgb(68, 66, 66);
            border-radius: 8px;
        }
        .inputBox{
            position: relative;
        }
        .inputUser{
            background: none;
            border: none;
            border-bottom: 1px solid white;
            outline: none;
            color: white;
            font-size: 15px;
            width: 100%;
            letter-spacing: 2px;
        }
        .labelInput{
            position: absolute;
            top: 0px;
            left: 0px;
            pointer-events: none;
            transition: .5s;
        }
        .inputUser:focus ~ .labelInput,
        .inputUser:valid ~ .labelInput{
            top: -20px;
            font-size: 12px;
            color: rgb(5, 5, 5);
        }
        #data_nascimento{
            border: none;
            padding: 8px;
            border-radius: 10px;
            outline: none;
            font-size: 15px;
        }
        #submit{
            background-image: linear-gradient(to right,rgb(255, 255, 255),  rgb(32,201,166));
            width: 100%;
            border: none;
            padding: 15px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            border-radius: 10px;
        }
        #submit:hover{
            background-image: linear-gradient(to right,rgb(0, 80, 172), rgb(255, 255, 255));
        }
    </style>
</head>
<body>
    <div class="box">
        <form action="" method="Post">
            <fieldset>
                <legend><b>Cadastro de estabelecimentoes</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="endereco" id="endereco" class="inputUser" required>
                    <label for="endereco" class="labelInput">Endereco</label>
                </div>
                <br>

                <div class="inputBox">
                    <input type="number" name="produtos" id="produtos" class="inputUser" required>
                    <label for="produtos" class="labelInput">Quantidade de Produtos</label>
                </div>
                <br>

                <div class="inputBox">
                    <input type="number" name="trabalhadores" id="trabalhadores" class="inputUser" required>
                    <label for="trabalhadores" class="labelInput">Quantidade de Trabalhadores</label>
                </div>
                <br><br>
             <div class="input-group">
             <div class="input-group-prepend"></div>
             <div class="input-group-append"></div>
            </div>
           <label>Diretor:
                      
                    <select name="id_diretor" class="dropdown-item">
                        <option>Selecione  o Diretor</option>
                     
                        <?php 
                            require_once '../DAO/diretorDao.php';
                             $diretorDAO = new diretorDao();
                            $lista = $diretorDAO->listar();
                             foreach ($lista as $li):
                                $selecinado = "";
                                if(isset($li->id))
                                    $selecinado = ($li->id == $li->id) ? "selected" : "";
                            ?>
                        <option value="<?= $li->id ?>" <?= $selecinado ?> >
                            <?= $li->nome  ?> 
                        </option>

                        <?php endforeach ?>

                    </select>
                <br><br>
                <input type="submit" name="submit" id="submit">
            </fieldset>
        </form>
    </div>
</body>
</html>