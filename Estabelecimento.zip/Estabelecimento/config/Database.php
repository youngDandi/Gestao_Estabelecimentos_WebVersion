<?php
/**
 * 
 */
class Database
{
	protected static $mysqli=null;

	function conectar()
	{  
		
		try{
		/*Introduza os argumentos para conexão a sua base de dados*/	
		self::mysqli = new mysqli("localhost", "root", "","Estabelecimento");
		self::mysqli->set_charset("utf8");
		
		}
		catch(Exception  $e)
		{
			echo "Execption: ".$e->getMessage();
		}

		return self::mysqli;
		
	}

}


?>