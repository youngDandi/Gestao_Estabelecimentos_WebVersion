<?php

class Trailler {
    private $id;
    private $endereco;
    private $loja;
    private $data;
    private $distribuicao;
    private $rua ;
    private $numero;
    private $geladaria;
    private $contrato;
    
   
  
    public function setID($id){
        $this->id = $id;
    }
   public function setEndereco($endereco) {
        $this->endereco= $endereco;
    }

 public function setLoja($loja){
        $this->loja= $loja;
    }
    public function setData ($data){
        $this->data= $data;
    }
   public function setDistribuicao($distribuicao){
        $this->distribuicao= $distribuicao;
    }


    public function setRua ($rua){
        $this->rua = $rua;
    }
    
   public function setNumero ($numero){
        $this->numero = $numero;
    }
     public function setGeladaria ($geladaria){
        $this->geladaria = $geladaria;
    }

      
   public function setContrato ($contrato){
        $this->contrato = $contrato;
    }

     public function getID(){
        return $this->id;
    }
    
     public function getEndereco(){
        return $this->endereco;
    }
    
     public function getLoja(){
        return $this->loja;
    }
    
     public function getData(){
        return $this->data;
    }
    public function getDistribuicao(){
        return $this->distribuicao;
    }
    public function getRua (){
        return $this->rua;
    }
   
    function getTrabalhadores() {
        return $this->trabalhadores;
    }

    public function getNumero(){
        return $this->numero;
    }
   public function getGeladaria() {
         return $this->geladaria;
    }
    public function getContrato() {
         return $this->contrato;
    }

}
