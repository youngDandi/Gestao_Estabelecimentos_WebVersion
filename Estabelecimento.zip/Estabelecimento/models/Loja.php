<?php

class Loja {
    private $id;
    private $caixas;
    private $departamentos;
    private $cafetaria;
    private $nome;
   
    function setCaixas($caixas) {
        $this->caixas= $caixas;
    }
    function setNome($nome) {
        $this->nome= $nome;
    }

    function setDepartamentos($departamentos){
        $this->departamentos = $departamentos;
    }

    

    public function setCafetaria ($cafetaria){
        $this->cafetaria = $cafetaria;
    }

    public function getCafetaria (){
        return $this->cafetaria;
    }
    function getCaixas() {
        return $this->caixas;
    }

  

    function getDepartamentos() {
        return $this->departamentos;
    }


    public function getNome(){
        return $this->nome;
    }
  
    public function setID($id){
        $this->id = $id;
    }

    public function getID(){
        return $this->id;
    }

}
