<?php

class Estabelecimento {
    private $id;
    private $endereco;
    private  $diretor;
    private $trabalahadores;
    private $produtos;
    
   
  
    public function setID($id){
        $this->id = $id;
    }
   public function setEndereco($endereco) {
        $this->endereco= $endereco;
    }

 
   public function setTrabalhadores($trabalhadores ){
        $this->trabalhadores = $trabalhadores;
    }


    public function setProdutos ($produtos){
        $this->produtos = $produtos;
    }
    
   public function setDiretor ($diretor){
        $this->diretor = $diretor;
    }

    public function getprodutos (){
        return $this->produtos;
    }
   
    function getTrabalhadores() {
        return $this->trabalhadores;
    }


    public function getID(){
        return $this->id;
    }
public function getDiretor(){
        return $this->diretor;
    }
   public function getEndereco() {
         return $this->endereco;
    }
}
