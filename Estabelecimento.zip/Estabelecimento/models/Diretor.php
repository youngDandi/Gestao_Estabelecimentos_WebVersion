<?php

class Diretor {
    public $id;
    private $nome;
    private $sexo;
    private $experiencia;
   
    function setExperiencia($experiencia) {
        $this->experiencia= $experiencia;
    }

    function setSexo($sexo) {
        $this->sexo = $sexo;
    }

    

    public function setNome ($nome){
        $this->nome = $nome;
    }

    public function getNome (){
        return $this->nome;
    }
    function getExperiencia() {
        return $this->experiencia;
    }

  

    function getSexo() {
        return $this->sexo;
    }

  
    public function setID($id){
        $this->id = $id;
    }

    public function getID(){
        return $this->id;
    }

}
