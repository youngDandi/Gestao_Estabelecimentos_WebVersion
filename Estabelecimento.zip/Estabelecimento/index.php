<?php
#Front Controller

define("path",$_SERVER["DOCUMENT_ROOT"]);
require_once path."/Estabelecimento/controllers/HomeControl.php";


$url =  $_SERVER["REQUEST_URI"];

//Rotas definidas
if($url =="/Estabelecimento/" || $url=="/Estabelecimento/home"){
  
    $homeControl = new HomeControl();
    $homeControl->index();
}
// diretor 
elseif($url=="/Estabelecimento/views/FormularioDiretor.php" || $url=="/Estabelecimento/views/FormularioDiretor.php"){
      $diretorControl = new DiretorControler();
    $diretorControl->registra();
}
elseif ($url=="/Estabelecimento/views/diretor.php") {
    $diretorControl = new DiretorControler();
     $diretorControl->homeDiretor();
}
// estabelecimento
   elseif ($url=="/Estabelecimento/views/estabelecimento.php") {
    $estabelecimentoControl = new EstabelecimentoControler();
     $estabelecimentoControl->homeEstabelecimento();
}
// lojas 

elseif ($url=="/Estabelecimento/views/loja.php") {
    $estabelecimentoCo = new lojaControler();
     $diretorControl->homeLoja();
}
 
else {
header('Status: 404 Not Found');
echo '<html><body><h1>Page Nao Encontrada</h1></body></html>';
}
?>
</script>