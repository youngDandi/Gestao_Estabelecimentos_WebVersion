<script>
    $(document).on("click","#submit",function(e){
    e.preventDefault();
    alert("ola");
});
</script>